package com.rmtheis.yandtran;

public class ApiKeys {
//  protected static final String YANDEX_API_KEY = "[Put your API key here]";
  public static final String YANDEX_API_KEY = "trnsl.1.1.20151023T103921Z.a96fdab4bb0af2db.2516370694c133e16642d4b72a29cf68904819be";
}
